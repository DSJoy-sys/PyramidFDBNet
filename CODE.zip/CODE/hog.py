import numpy as np
from skimage.feature import hog
def get_hog(img):
    # hog extraction
    _, hog_image = hog(img, orientations=8, pixels_per_cell=(16, 16),
                       cells_per_block=(1, 1), visualize=True)
    hist,bin = np.histogram(hog_image)
    return hist