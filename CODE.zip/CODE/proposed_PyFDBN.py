
import DBN
from Main import fuse_regress
from keras.layers import Input, Conv2D, BatchNormalization, Activation, Add, GlobalAveragePooling2D, Dense
from keras.models import Model
import numpy as np
def conv_block(x, filters, kernel_size=3, stride=1):
    x = Conv2D(filters, kernel_size=kernel_size, strides=stride, padding='same')(x)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    return x

def residual_block(x, filters, kernel_size=3, stride=1):
    shortcut = x

    x = conv_block(x, filters, kernel_size, stride)
    x = conv_block(x, filters, kernel_size)

    # Adjust shortcut connection to match the number of filters
    shortcut = Conv2D(filters, kernel_size=1, strides=stride, padding='same')(shortcut)

    x = Add()([x, shortcut])
    return x

def deep_pyramid_residual_network(input_shape=(224, 224, 3), num_classes=1):
    input_tensor = Input(shape=input_shape)

    # Initial convolution
    x = conv_block(input_tensor, 64, kernel_size=7, stride=2)

    # Residual blocks with pyramid connections
    for filters in [64, 128, 256, 512]:
        for _ in range(3):
            x = residual_block(x, filters)

        # Pyramid connection
        x = Conv2D(filters, kernel_size=1, strides=2)(x)
        x = BatchNormalization()(x)
        x = Activation('relu')(x)

    # Global average pooling and fully connected layer
    x = GlobalAveragePooling2D()(x)
    x = Dense(num_classes, activation='softmax')(x)

    model = Model(inputs=input_tensor, outputs=x)
    return model
from sklearn.model_selection import train_test_split
import tensorflow as tf


def main(data, label, tr, ACC, TPR, TNR):
    X = np.load('inp_feat.npy', allow_pickle=True).astype(float)
    Y = label
    tr_data, tst_data, tr_lab, tst_lab = train_test_split(X, Y, train_size=tr)
    num_clas = 1
    model = deep_pyramid_residual_network(num_classes=num_clas)
    model.compile(metrics=['accuracy'], optimizer='adam', loss='mse')
    x_train = np.resize(tr_data,(tr_data.shape[0],224,224,3))
    x_test = np.resize(tst_data,(tst_data.shape[0],224,224,3))


    model.fit(x_train, tr_lab, batch_size=50, epochs=1, verbose=1)
    # plot_model(model, to_file='model_DNFN.jpg', show_shapes=True, dpi=800)
    l1 = model.predict(x_test)



    ###########    weight
    opt = tf.keras.optimizers.legacy.RMSprop()  #### weight
    m = tf.keras.models.Sequential([tf.keras.layers.Dense(2)])
    m.compile(opt, loss='mse')

    m.fit(data, label)  # Training.
    w = m.get_weights()[0]

    #####   PyDB layer

    y = []
    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            y.append(data[i, j] * w[j][0])
    y = np.array(y)
    l1 = np.resize(l1, (y.shape))
    ########## applyig fractional concept

    h = 0.5
    fus = h * y + ((1 / 2) * h * l1)
    ############   regression

    l2 = fuse_regress.reg(data, fus, 0.9, label)
    l2 = np.resize(l2, (len(data), 1))
    features = np.hstack((data, l2))

    ########  DBN model
    o3 = DBN.classify(features, label, tr)
    predict = np.array(o3)
    target = tr_lab

    tp, tn, fn, fp = 0, 0, 0, 0

    uni = np.unique(target)
    for j in range(len(uni)):
        tp = tn = fn = fp = 1
        c = uni[j]
        for i in range(len(target)):
            if target[i] == c and predict[i] == c:
                tp += 1
            if target[i] != c and predict[i] != c:
                tn += 1
            if target[i] == c and predict[i] != c:
                fn += 1
            if target[i] != c and predict[i] == c:
                fp += 1

    fn = fn / len(uni)
    fp = fp / len(uni)

    TPR.append(tp / (tp + fn))

    TNR.append(tn / (tn + fp))
    ACC.append((tp + tn) / (tp + tn + fp + fn))
