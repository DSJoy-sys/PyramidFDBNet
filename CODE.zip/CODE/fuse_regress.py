import numpy as np
from sklearn.linear_model import LinearRegression


def reg(Fea,L,tr,label):
    L = np.resize(L,(len(Fea),1))
    Data=np.concatenate((Fea,L),axis=1)
    Data = np.nan_to_num(Data)
    reg=LinearRegression().fit(Data, label)
    Prediction=(reg.predict(Data)).flatten()
    Prediction = Prediction.astype(int)

    return Prediction