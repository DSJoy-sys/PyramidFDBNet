from tensorflow.keras.applications import ResNet50
import cv2
import numpy as np
def main(img):
    img = cv2.cvtColor(img,cv2.COLOR_GRAY2RGB)
    model = ResNet50(weights="imagenet", include_top=False)

    features = model.predict(img.reshape(1, img.shape[0], img.shape[1], 3), batch_size=100)
    hist, bin = np.histogram(features)
    return hist

