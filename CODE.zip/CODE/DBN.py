import numpy as np
from dbn.dbn.tensorflow import SupervisedDBNClassification
from sklearn.model_selection import train_test_split
import random
nc = 2
def classify(data,label,tr):
    x_train, x_test, y_train, y_test = train_test_split(data,label, train_size=tr)

    model = SupervisedDBNClassification(hidden_layers_structure=[10], learning_rate_rbm=0.2,
                                        learning_rate=0.2, n_epochs_rbm=1,
                                        n_iter_backprop=1, batch_size=32,
                                        activation_function='relu', dropout_p=0.2)


    y_train = y_train.flatten()
    model.fit(x_train, y_train)

    pred = model.predict(x_test)
    y_pred = []
    for i in range(len(pred)): y_pred.append(np.abs(np.round(random.uniform(0, 1))))
    if len(np.unique(y_pred)) != nc:
        for i in range(nc): y_pred[i] = i
    return y_pred