import torch, numpy as np
from load_data import MyDatasets
from utils import *
from network import ResNet
# from torch.utils.data import Dataset, DataLoader
import os, pickle
# from torchvision.utils import save_image
import argparse
from PIL import Image
import matplotlib.pyplot as plt


def loadnet(npoints=10,path_to_model=None):
    # Load the trained model.
    net = ResNet(num_maps=npoints)
    checkpoint = torch.load(path_to_model, map_location='cpu')
    checkpoint = {k.replace('module.',''): v for k,v in checkpoint.items()}
    net.load_state_dict(checkpoint,strict=False)
    return net.to('cpu')

# def getitem(image,AU_coords,AU_intensity):
#     # image, AU_coords, AU_intensity = self.fetch(index)
#     nimg = len(image)
#     sample = dict.fromkeys(['Im'], None)
#     out = dict.fromkeys(['image','points'])
#     image_np = torch.from_numpy((image/255.0).swapaxes(2,1).swapaxes(1,0))
#     out['image'] = image_np.type_as(torch.FloatTensor())
#     out['AU_coords'] = np.floor(AU_coords)
#
#     target = generate_target(out['AU_coords'], AU_intensity)
#     target = torch.from_numpy(target).type_as(torch.FloatTensor())
#     sample['target'] = target
#     sample['pts'] = out['AU_coords']
#     sample['intensity'] = AU_intensity
#     sample['Im'] = out['image']
#     return sample
